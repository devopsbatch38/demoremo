from flask import Flask
import os
import mysql.connector

app = Flask(__name__)

@app.route('/')
def home():
    db = mysql.connector.connect(
        host=os.environ['DB_HOST'],
        user=os.environ['DB_USER'],
        password=os.environ['DB_PASSWORD'],
        database=os.environ['DB_NAME']
    )
    cursor = db.cursor()
    cursor.execute("SHOW TABLES")
    return "Backend connected to DB!"
